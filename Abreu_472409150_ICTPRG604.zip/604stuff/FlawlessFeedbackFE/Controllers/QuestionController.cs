﻿using FlawlessFeedbackFE.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Controllers
{
    public class QuestionController : Controller
    {
        HttpClient _client;

        string controllerName = "Question";

        // GET: QuestionController
        public QuestionController(IHttpClientFactory httpClientFactory)
        {
            _client = httpClientFactory.CreateClient("FlawlessFeedbackApiClient");
        }
        // GET: SurveyController
        /// <summary>
        /// Goes to the index of Questions
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var questions = ApiRequest<Question>.GetList(_client, controllerName);
            return View(questions);
        }

        // GET: QuestionController/Details/5
        /// <summary>
        /// View Details of a question
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Details(int id)
        {
            var question = ApiRequest<Question>.GetSingle(_client, controllerName, id);
            return View(question);
        }

        private List<SelectListItem> GetSurvey()
        {
            var surveyList = ApiRequest<Survey>.GetList(_client, "Survey");

            var selectListSurvey = surveyList.OrderBy(c => c.SurveyTopic).Select(o => new SelectListItem
            { Text = o.SurveyTopic, Value = o.SurveyID.ToString() }).ToList();
            return selectListSurvey;
        }

        // GET: QuestionController/Create
        /// <summary>
        /// Create a Question
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            Question question = new Question();
            question.SurveyDropDown = GetSurvey();
            return View(question);
            
        }

        // POST: QuestionController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Question question)
        {
            try
            {
                ApiRequest<Question>.Post(_client, controllerName, question);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: QuestionController/Edit/5
        /// <summary>
        /// Edit a Question
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("Token") != null)
            {
                // Set the authorization header to contain our token (and the type of token)
                _client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
                var question = ApiRequest<Question>.GetSingle(_client, controllerName, id);
                return View(question);
            }
            else 
            {
                // Redirect to login page
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: QuestionController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Question questions)
        {
            _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
            try
            {
                ApiRequest<Question>.Put(_client, controllerName, id, questions);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: QuestionController/Delete/5
        /// <summary>
        /// Delete a Question
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("Token") != null)
            {
                // Set the authorization header to contain our token (and the type of token)
                _client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
                var question = ApiRequest<Question>.GetSingle(_client, controllerName, id);
                return View(question);
            }
            else 
            {
                // Redirect to login page
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: QuestionController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Question question)
        {
            _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
            try
            {
                ApiRequest<Question>.Delete(_client, controllerName, id);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        /// <summary>
        /// View Questions per Survey
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult QuestionsPerSurvey(int id)
        {
            var response = _client.GetAsync($"Question/GetBySurvey/{id}").Result;
            var questions = response.Content.ReadAsAsync<List<Question>>().Result;
            return View(questions);
        }
    }
}

