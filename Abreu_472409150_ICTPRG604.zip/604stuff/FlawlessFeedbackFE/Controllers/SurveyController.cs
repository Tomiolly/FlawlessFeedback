﻿using ChartJSCore.Models;
using CsvHelper;
using FlawlessFeedbackFE.Models;
using FlawlessFeedbackFE.Models.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Controllers
{
    public class SurveyController : Controller
    {

        HttpClient _client;

        string controllerName = "Survey";

        IWebHostEnvironment _hostingEnvironment;

        public SurveyController(IHttpClientFactory httpClientFactory, IWebHostEnvironment hostingEnvironment)
        {
            _client = httpClientFactory.CreateClient("FlawlessFeedbackApiClient");
            _hostingEnvironment = hostingEnvironment;
        }


        // GET: SurveyController
        /// <summary>
        /// Goes to Index of Survey
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var sesh = HttpContext.Session;
            var survey = ApiRequest<Survey>.GetList(_client, controllerName);
            return View(survey);
        }

        // GET: SurveyController/Details/5
        /// <summary>
        /// View Details of a Survey
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Details(int id)
        {

                var survey = ApiRequest<Survey>.GetSingle(_client, controllerName, id);
                return View(survey);

        }

        // GET: SurveyController/Create
        /// <summary>
        /// Create a Survey
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            if(HttpContext.Session.GetString("Token") == null && HttpContext.Session.GetString("FirstName") != null)
            {
                Survey surveyFrame = new Survey();
                surveyFrame.DateCreated = DateTime.Now;
                surveyFrame.CreatorName = HttpContext.Session.GetString("FirstName");
                return View(surveyFrame);
            }
            if (HttpContext.Session.GetString("Token") != null)
            {
                Survey surveyFrame = new Survey();
                surveyFrame.DateCreated = DateTime.Now;
                surveyFrame.CreatorName = HttpContext.Session.GetString("UserName");
                return View(surveyFrame);
            }
            else 
            {
                Survey surveyFrame = new Survey();
                surveyFrame.DateCreated = DateTime.Now;
                return View(surveyFrame);
            }


        }



        // POST: SurveyController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Survey survey)
        {
            try
            {
                ApiRequest<Survey>.Post(_client, controllerName, survey);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        /// Creates a survey and redirects the user.
        /// </summary>
        /// <param name="survey"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateAndRedirect(Survey survey)
        {
            try
            {
                var result = ApiRequest<Survey>.Post(_client, controllerName, survey);
                return RedirectToAction("Create", "Question", new { id = result.SurveyID });
            }
            catch(Exception e)
            {
                return View();
            }
        }


        // GET: SurveyController/Edit/5
        /// <summary>
        /// Edit a Survey
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Edit(int id)
        {
            //If we have a value in our token
            if (HttpContext.Session.GetString("Token") != null)
            {
                // Set the authorization header to contain our token (and the type of token)
                _client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
                var survey = ApiRequest<Survey>.GetSingle(_client, controllerName, id);
                return View(survey);
            }
            else
            {
                // Redirect to login page
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: SurveyController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Survey survey)
        {
            _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
            try
            {
                ApiRequest<Survey>.Put(_client, controllerName, id, survey);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SurveyController/Delete/5
        /// <summary>
        /// Delete a Survey
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("Token") != null)
            {
                // Set the authorization header to contain our token (and the type of token)
                _client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
                var survey = ApiRequest<Survey>.GetSingle(_client, controllerName, id);
                return View(survey);
            }
            else 
            {
                // Redirect to login page
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: SurveyController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Survey survey)
        {
            _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());

            try
            {
                ApiRequest<Survey>.Delete(_client, controllerName, id);

                return RedirectToAction(nameof(Index));
            }
            catch(Exception e)
            {
                return View();
            }
        }

        /// <summary>
        /// Exports a CSV from the Report Page
        /// </summary>
        /// <returns></returns>
        public IActionResult ExportCSV()
        {
            var response = _client.GetAsync("Survey/NumberOfQuestions").Result;
            List<SurveyQuestionReportViewModel> svyViewModel = response.Content.ReadAsAsync<List<SurveyQuestionReportViewModel>>().Result;
            var stream = new MemoryStream();

            using (var writeFile = new StreamWriter(stream, leaveOpen: true)) 
            {
                var csv = new CsvWriter(writeFile, CultureInfo.CurrentCulture, true);
                csv.WriteRecords(svyViewModel);
            }

            stream.Position = 0;
            return File(stream, "application/octet-stream", $"ReportData_{DateTime.Now.ToString("ddMMM_HHmmss")}.csv");
        }

        /// <summary>
        /// Displays a Bar Chart for Number of Questions per Survey
        /// </summary>
        /// <returns></returns>
        public IActionResult DisplayChart()
        {
           
            var response = _client.GetAsync("Survey/NumberOfQuestions").Result;

            List<SurveyQuestionReportViewModel> svyViewModel = response.Content.ReadAsAsync<List<SurveyQuestionReportViewModel>>().Result;

            var numberOfQuestions = svyViewModel.Select(x => (double?)x.NumberOfQuestions).ToList();
            var chartLabels = svyViewModel.Select(x => x.SurveyTopic).ToList();

            Chart chart = new Chart();
            chart.Type = Enums.ChartType.Bar;

            ChartJSCore.Models.Data data = new ChartJSCore.Models.Data();
            data.Labels = chartLabels;

            BarDataset dataset = new BarDataset()
            {
                Label = "Number of Questions",
                Data = numberOfQuestions,
                Type = Enums.ChartType.Bar,
            };
            data.Datasets = new List<Dataset>();
            data.Datasets.Add(dataset);
            chart.Data = data;
            ViewData["chart"] = chart;
            return View();

        }

        /// <summary>
        /// Saves a file to directory
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            try
            {
                if(file.Length > 0)
                {
                    string folderRoot = Path.Combine(_hostingEnvironment.ContentRootPath, "wwwroot\\Uploads");
                    string filePath = file.FileName;
                    filePath = Path.Combine(folderRoot, filePath);
                    using (var stream = new FileStream(filePath, FileMode.Create)) 
                    {
                        await file.CopyToAsync(stream);
                    }
                }
                return Ok(new { success = true, message = "File Uploaded" });
            }
            catch (Exception)
            {
                return BadRequest(new { success = false, message = "An error occurred" });
            }
        }

    }
}
