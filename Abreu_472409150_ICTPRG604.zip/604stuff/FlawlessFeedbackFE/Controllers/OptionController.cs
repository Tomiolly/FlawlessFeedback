﻿using FlawlessFeedbackFE.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Controllers
{
    public class OptionController : Controller
    {
        HttpClient _client;

        string controllerName = "Option";

        public OptionController(IHttpClientFactory httpClientFactory)
        {
            _client = httpClientFactory.CreateClient("FlawlessFeedbackApiClient");
        }


        // GET: OptionController
        /// <summary>
        /// Go to Index of options
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var option = ApiRequest<Option>.GetList(_client, controllerName);
            return View(option);
        }

        /// <summary>
        /// View a question
        /// </summary>
        /// <returns></returns>
        private List<SelectListItem> GetQuestion()
        {
            var questionList = ApiRequest<Question>.GetList(_client, "Question");

            var selectListQuestion = questionList.OrderBy(c => c.QuestionText).Select(o => new SelectListItem
            { Text = o.QuestionText, Value = o.QuestionID.ToString() }).ToList();
            return selectListQuestion;
        }

        
        // GET: OptionController/Details/5
        /// <summary>
        /// View details of an Option
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Details(int id)
        {

            var option = ApiRequest<Option>.GetSingle(_client, controllerName, id);
            return View(option);

        }

        // GET: OptionController/Create 
        /// <summary>
        /// Create an Option
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            Option option = new Option();
            option.QuestionDropDown = GetQuestion();
            return View(option);

        }

        // POST: OptionController/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Option option)
        {
            try
            {
                ApiRequest<Option>.Post(_client, controllerName, option);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: OptionController/Edit 
        /// <summary>
        /// Edit an Option
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Edit(int id)
        {
            if (HttpContext.Session.GetString("Token") != null)
            {
                // Set the authorization header to contain our token (and the type of token)
                _client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
                var option = ApiRequest<Option>.GetSingle(_client, controllerName, id);
                return View(option);
            }
            else
            {
                // Redirect to login page
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: OptionController/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Option option)
        {
            _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
            try
            {
                ApiRequest<Option>.Put(_client, controllerName, id, option);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: OptionController/Edit 
        /// <summary>
        /// Delete an Option
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("Token") != null)
            {
                // Set the authorization header to contain our token (and the type of token)
                _client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
                var option = ApiRequest<Option>.GetSingle(_client, controllerName, id);
                return View(option);
            }
            else 
            {
                // Redirect to login page
                return RedirectToAction("Login", "Home");
            }
        }

        // POST: OptionController/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Option option)
        {
            _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("bearer", HttpContext.Session.GetString("Token").ToString());
            try
            {
                ApiRequest<Option>.Delete(_client, controllerName, id);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception e)
            {
                return View();
            }
        }

    }
}
