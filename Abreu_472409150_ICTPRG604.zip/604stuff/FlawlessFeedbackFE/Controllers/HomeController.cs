﻿ using FlawlessFeedbackFE.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        HttpClient _client;

        public HomeController(ILogger<HomeController> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _client = httpClientFactory.CreateClient("FlawlessFeedbackApiClient");
        }


        /// <summary>
        /// Displays the Home page
        /// </summary>
        /// <returns>Index View</returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Displays the FAQ page
        /// </summary>
        /// <returns>FAQ view</returns>
        public IActionResult FAQ()
        {
            return View();
        }

        /// <summary>
        /// Displays the Login page
        /// </summary>
        /// <returns>Login view</returns>
        public IActionResult Login()
        {
            ViewData["Error"] = null;
            return View();
        }

        /// <summary>
        /// Validates users credentials
        /// </summary>
        /// <param name="userInfo"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Login(UserInfo userInfo)
        {
            HttpResponseMessage result = _client.PostAsJsonAsync("Token/GenerateToken", userInfo).Result;
            
            switch (result.StatusCode)
            {
                case System.Net.HttpStatusCode.BadRequest:
                    ViewData["Error"] = "Invalid Login Details";
                    return View();
                case System.Net.HttpStatusCode.OK:
                    // retrieve the token from the body;
                    string token = result.Content.ReadAsStringAsync().Result;
                    HttpContext.Session.SetString("Token", token);
                    HttpContext.Session.SetString("UserName", userInfo.UserName);
                    // Session management
                    HttpContext.Session.SetString("FirstName", "");
                    if (TempData.Peek("RedirectUrl") != null) 
                    {
                        return Redirect(TempData["RedirectUrl"].ToString());
                    }
                    return RedirectToAction(nameof(Index));
                default:
                    ViewData["Error"] = "Something Went Wrong";
                    return View();
            }



        }

        /// <summary>
        /// Logs out of the application
        /// </summary>
        /// <returns></returns>
        public IActionResult LogOut()
        {
            if (HttpContext.Session.GetString("Token") != null)
            {
                HttpContext.Session.Remove("Token");
                HttpContext.Session.Remove("FirstName");
            }
            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// Saves a Guest name for use in the application
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        public IActionResult SaveName(IFormCollection collection) 
        {
            HttpContext.Session.SetString("FirstName", (string)collection["firstName"]);
            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// Displays the Privacy view
        /// </summary>
        /// <returns></returns>
        public IActionResult Privacy()
        {
            return View();
        }

        /// <summary>
        /// Error response
        /// </summary>
        /// <returns></returns>
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
