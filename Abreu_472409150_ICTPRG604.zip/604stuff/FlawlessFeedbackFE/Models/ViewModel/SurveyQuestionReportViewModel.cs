﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Models.ViewModel
{
    public class SurveyQuestionReportViewModel
    {
        public string SurveyTopic { get; set; }
        public int NumberOfQuestions { get; set; }
    }
}
