﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Models
{
    public class Question
    {
        [Display(Name = "Question ID")]
        public int QuestionID { get; set; }
        [Display(Name = "Question")]
        [Required(ErrorMessage = "A Question is Required")]
        public string QuestionText { get; set; }
        [Display(Name = "Survey ID")]

        public int SurveyID { get; set; }

        // Relationships
        public ICollection<Option> Options { get; set; }
        public virtual Survey Survey { get; set; }
        public virtual List<SelectListItem> SurveyDropDown { get; set; }

    }
}
