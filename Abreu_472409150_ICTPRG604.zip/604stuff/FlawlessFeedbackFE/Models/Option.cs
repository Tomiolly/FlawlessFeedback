﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Models
{
    public class Option
    {
        [Display(Name = "Option ID")]
        public int OptionID { get; set; }
        [Display(Name = "Answer")]
        [Required(ErrorMessage = "Required")]
        public string OptionText { get; set; }
        [Display(Name = "Option")]
        [Required(ErrorMessage = "Required")]
        public string OptionLetter { get; set; }
        [Display(Name = "Question ID")]

        public int QuestionID { get; set; }
        // Relationships

        public Question Question { get; set; }

        public virtual List<SelectListItem> QuestionDropDown { get; set; }
    }
}
