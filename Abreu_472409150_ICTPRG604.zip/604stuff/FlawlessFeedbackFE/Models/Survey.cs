﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlawlessFeedbackFE.Models
{
    public class Survey
    {
        [Display(Name = "Survey ID")]
        public int SurveyID { get; set; }
        [Display(Name = "Topic")]
        [Required(ErrorMessage = "A Topic is Required")]
        public string SurveyTopic { get; set; }
        [Display(Name = "Creator")]
        [Required(ErrorMessage = "A Creator is Required")]
        public string CreatorName { get; set; }
        [Display(Name = "Date Published")]
        public DateTime DateCreated { get; set; }
        [Display(Name = "Further Comments")]
        public string FurtherComments { get; set; }
        public string Logo { get; set; }

        // Relationships
        public ICollection<Question> Questions { get; set; }
    }
}
