﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlawlessFeedbackAPI.DatabaseService
{
    public static class DatabaseService
    {
        public static void MigrateInitialisation(IApplicationBuilder app) 
        {
            
        }
    }
}
